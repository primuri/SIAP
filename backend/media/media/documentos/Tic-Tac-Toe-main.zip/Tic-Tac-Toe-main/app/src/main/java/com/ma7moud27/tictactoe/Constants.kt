package com.ma7moud27.tictactoe

enum class Constants{
    PLAYER_NAME,
    OPPONENT_NAME,
    COMPUTER

}
